Iconset: Logos and Brands - Line Filled (https://www.iconfinder.com/iconsets/logos-and-brands-adobe)
Author: Flatart (https://www.iconfinder.com/Flatart)
License: Creative Commons (Attribution 3.0 Unported) (http://creativecommons.org/licenses/by/3.0/)
Download date: 2024-02-14